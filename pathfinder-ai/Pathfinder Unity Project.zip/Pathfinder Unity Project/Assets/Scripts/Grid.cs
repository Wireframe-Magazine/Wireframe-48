﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Grid
{
    public static int Width;
    public static int Height;

    public static int StartX;
    public static int StartY;

    public static int TargetX;
    public static int TargetY;

    public static GameObject[,] grid;
}
