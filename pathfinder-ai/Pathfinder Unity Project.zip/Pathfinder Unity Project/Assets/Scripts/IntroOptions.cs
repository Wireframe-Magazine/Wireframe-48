﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class IntroOptions : MonoBehaviour
{
    private const int kMaxDimensions = 15;

    [SerializeField] private Text WidthText;
    [SerializeField] private InputField WidthInputField;
    [SerializeField] private Text HeightText;
    [SerializeField] private InputField HeightInputField;

    [SerializeField] private GameObject IntroCanvas;
    [SerializeField] private GameObject GridCanvas;

    [SerializeField] private GameObject WidthWarningText;
    [SerializeField] private GameObject HeightWarningText;

    //------------------------------------------------------------------------------------------------------

    void OnDisable()
    {
        if (WidthText != null)
        {
            WidthText.text = "";
            WidthText.color = Color.black;
        }

        if (WidthInputField != null)
            WidthInputField.text = "";

        if (WidthWarningText != null)
            WidthWarningText.SetActive(false);

        if (HeightText != null)
        {
            HeightText.text = "";
            HeightText.color = Color.black;
        }

        if (HeightInputField != null)
            HeightInputField.text = "";

        if (HeightWarningText != null)
            HeightWarningText.SetActive(false);
    }

    //------------------------------------------------------------------------------------------------------

    public void Begin()
    {
        if(WidthText != null && HeightText != null)
        {
            bool widthValid = true;
            bool heightValid = true;

            //Validate the width input.
            string sWidth = WidthText.text;
            int iWidth = 10;
            if (sWidth != "")
            {
                iWidth = int.Parse(sWidth);
                if (iWidth <= 0 || iWidth > kMaxDimensions)
                    widthValid = false;
            }

            //Validate the height input.
            string sHeight = HeightText.text;
            int iHeight = 10;
            if (sHeight != "")
            {
                iHeight = int.Parse(sHeight);
                if (iHeight <= 0 || iHeight > kMaxDimensions)
                    heightValid = false;
            }

            //Exit if eith width or height is invalid.
            if(!widthValid || !heightValid)
            {
                if (WidthWarningText != null)
                { 
                    if (!widthValid)
                        WidthWarningText.SetActive(true);
                    else
                        WidthWarningText.SetActive(false);
                }

                if (HeightWarningText != null)
                {
                    if (!heightValid)
                        HeightWarningText.SetActive(true);
                    else
                        HeightWarningText.SetActive(false);
                }

                return;
            }


            //Set the dimensions of the grid.
            Grid.Width  = iWidth;
            Grid.Height = iHeight;

            //Switch canvases.
            if (IntroCanvas != null)
                IntroCanvas.SetActive(false);
            if (GridCanvas != null)
                GridCanvas.SetActive(true);

        }
    }

    //------------------------------------------------------------------------------------------------------

    public void ValidWidthEntry()
    {
        if (WidthText != null)
        {
            string sWidth = WidthText.text;
            if (sWidth != "")
            {
                int iWidth = int.Parse(sWidth);
                if (iWidth <= 0 || iWidth > kMaxDimensions)
                {
                    WidthText.color = Color.red;
                }
                else
                {
                    WidthText.color = Color.black;

                    if (WidthWarningText != null)
                    {
                        WidthWarningText.SetActive(false);
                    }
                }
            }
        }
    }

    //------------------------------------------------------------------------------------------------------

    public void ValidHeightEntry()
    {
        if (HeightText != null)
        {
            string sHeight = HeightText.text;
            if (sHeight != "")
            {
                int iHeight = int.Parse(sHeight);
                if (iHeight <= 0 || iHeight > kMaxDimensions)
                {
                    HeightText.color = Color.red;
                }
                else
                {
                    HeightText.color = Color.black;

                    if (HeightWarningText != null)
                    {
                        HeightWarningText.SetActive(false);
                    }
                }
            }
        }
    }

    //------------------------------------------------------------------------------------------------------
}
